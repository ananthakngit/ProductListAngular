import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {
  product = {
    Id:0,
    ProductsCode: '',
    ProductCategory: '',
    ProductName: ''
  };
  submitted = false;

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
  }

  createProduct(): void {
    const data = {
      ProductsCode: this.product.ProductsCode,
      ProductCategory: this.product.ProductCategory,
      ProductName:this.product.ProductName
    };

    this.productService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newProduct(): void {
    this.submitted = false;
    this.product = {
      Id:0,
      ProductsCode: '',
      ProductCategory: '',
      ProductName: ''
    };
  }

}