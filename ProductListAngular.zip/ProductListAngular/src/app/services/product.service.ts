import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders,HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs';

const baseURL = 'http://localhost:5000/Products';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private httpClient: HttpClient) { }

  readAll(data:any): Observable<any> {
    return this.httpClient.get(baseURL,data);
  }

  read(id:any): Observable<any> {
    return this.httpClient.get(`${baseURL}/${id}`);
  }

  create(data:any): Observable<any> {
    return this.httpClient.post(baseURL, data);
  }

  update(id:any, data:any): Observable<any> {
    return this.httpClient.put(`${baseURL}/${id}`, data);
  }

  delete(id:any): Observable<any> {
    return this.httpClient.delete(`${baseURL}/${id}`);
  }

  deleteAll(): Observable<any> {
    return this.httpClient.delete(baseURL);
  }

  searchByName(data:any): Observable<any> {
   // return this.httpClient.get(`${baseURL}?name=${name}`);
   let headers = new HttpHeaders();
   headers.append('Content-Type', 'application/json');

   let dataPrincipalBlnc = {"Id":"0",
                          "ProductName":data.ProductName,
                          "ProductCategory":data.ProductCategory,
                          "ProductCode":data.ProductCode}
   

   let body = JSON.stringify(data);


   return this.httpClient.post(baseURL,body);
  }
}
