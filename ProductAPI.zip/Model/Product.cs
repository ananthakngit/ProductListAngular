using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductsApi.Model
{
    public class Product
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string ProductsCode { get; set; }

        public string ProductCategory { get; set; }

        public string ProductName { get; set; }
    }
}
