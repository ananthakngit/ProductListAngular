﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProductsApi.Model;
using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;

namespace ProductsApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly MyDbContext _context;
        private readonly ILogger<ProductsController> _logger;
        private readonly MvcOptions _mvcOptions;

        public ProductsController(MyDbContext context,ILogger<ProductsController> logger, IOptions<MvcOptions> mvcOptions)
        {
            _logger = logger;
            _context = context;
            _mvcOptions = mvcOptions.Value;
        }

        [HttpGet]
        public List<Product> Get()
        {
            List<Product> prd = new List<Product>();
            prd = _context.Product.Take(_mvcOptions.MaxModelBindingCollectionSize).ToList();    
            return prd;
        }

        [HttpGet("{id}")]
        public  Product Get(int id)
        {
            Product prd = new Product();
            prd = _context.Product.SingleOrDefault(x => x.Id == id);

            return prd;
        }

        [HttpPut("{id}")]
        public IEnumerable<Product> Put(int id, Product prd)
        {

            List<Product> prd2 = new List<Product>();
            _context.Product.Update(prd);
            prd2 = _context.Product.Take(_mvcOptions.MaxModelBindingCollectionSize).ToList();
            return prd2;
        }

        [HttpDelete("{id}")]
        public IEnumerable<Product> Delete(int id)
        {
            Product prd = new Product();
            prd = _context.Product.Include(x => x.ProductName)
            .FirstOrDefault(x => x.Id == id);
            
            _context.Product.Remove(prd);
            _context.SaveChanges();
            List<Product> prd2 = new List<Product>();
            prd2 = _context.Product.Take(_mvcOptions.MaxModelBindingCollectionSize).ToList();
            return prd2;
        }

        [HttpPost]
        public IEnumerable<Product> Post([FromQuery] Product prdReq)
        {
            List<Product> prd = new List<Product>();
            if (!_context.Product.Any(o => o.ProductName == prdReq.ProductName && o.ProductsCode == prdReq.ProductsCode && o.ProductCategory == prdReq.ProductCategory))
            {
                _context.Product.Add(prdReq);
                _context.SaveChanges();
                prd = _context.Product.Take(_mvcOptions.MaxModelBindingCollectionSize).ToList();
            }
          


            return prd;
        }
    }
}
